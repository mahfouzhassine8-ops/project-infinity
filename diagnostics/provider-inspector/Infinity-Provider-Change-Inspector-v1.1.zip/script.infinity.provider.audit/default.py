# Infinity Provider Change Inspector 1.1
# Read-only for providers and Infinity. Only writes its own JSON/ZIP audit output.
# Kodi 19+ Python 3. No network, no provider search execution, no add-on settings read.
from __future__ import annotations

import ast
import datetime
import hashlib
import io
import json
import os
import re
import shutil
import sys
import zipfile
import xml.etree.ElementTree as ET

TARGET_IDS = (
    'plugin.video.thecrew',
    'script.module.thecrew',
    'script.thecrew.artwork',
    'script.thecrew.metadata',
    'plugin.video.watchnixtoons2',
    'plugin.video.watchnixtoons2.kodi19',
)
MAX_FILES = 1800
MAX_FILE_BYTES = 8 * 1024 * 1024
MAX_PY_PARSE = 350 * 1024
MAX_ARCHIVES_PER_ID = 8
MAX_TOTAL_SOURCE_BYTES = 96 * 1024 * 1024  # avoid unbounded disk/ZIP reads
ALLOWED_EXTS = ('.py', '.xml', '.json', '.ini', '.yaml', '.yml', '.toml')
SKIP_DIRS = {'__pycache__', '.git', 'addon_data', 'userdata', 'cache', 'temp'}


def utcstamp():
    return datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')


def sha_bytes(data):
    return hashlib.sha256(data).hexdigest()


def sha_file(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        while True:
            buf = f.read(1024 * 128)
            if not buf:
                break
            h.update(buf)
    return h.hexdigest()


def clean_rel(name):
    name = name.replace('\\', '/')
    parts = name.split('/')
    if not name or name.startswith('/') or any(p in ('..', '') for p in parts):
        return None
    if any(p.lower() in SKIP_DIRS for p in parts[:-1]):
        return None
    if not name.lower().endswith(ALLOWED_EXTS):
        return None
    return name


def metadata(data):
    try:
        root = ET.fromstring(data)
        if root.tag != 'addon':
            return None
        ext = []
        for x in root.findall('extension'):
            if x.attrib.get('point', '').startswith('xbmc.python.'):
                ext.append({'type': x.attrib.get('point', ''), 'entrypoint': x.attrib.get('library', '')})
        deps = []
        for req in root.findall('./requires/import'):
            deps.append({'id': req.get('addon', ''), 'version': req.get('version', '')})
        return {
            'id': root.get('id', ''), 'version': root.get('version', ''),
            'provider': root.get('provider-name', ''),
            'entrypoints': ext,
            'dependencies': sorted(deps, key=lambda x: x['id']),
        }
    except Exception:
        return None


def signatures(data):
    try:
        tree = ast.parse(data.decode('utf-8-sig'), type_comments=False)
    except (UnicodeDecodeError, SyntaxError, ValueError):
        return []
    sigs = []
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            args = [a.arg for a in node.args.posonlyargs + node.args.args + node.args.kwonlyargs]
            sigs.append('%s(%s)' % (node.name, ','.join(args[:12])))
        elif isinstance(node, ast.ClassDef):
            for method in node.body:
                if isinstance(method, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    args = [a.arg for a in method.args.posonlyargs + method.args.args + method.args.kwonlyargs]
                    sigs.append('%s.%s(%s)' % (node.name, method.name, ','.join(args[:12])))
        if len(sigs) >= 250:
            break
    return sorted(sigs)[:250]


def inspect_directory(path):
    xmlpath = os.path.join(path, 'addon.xml')
    if not os.path.isfile(xmlpath) or os.path.islink(xmlpath):
        return None
    try:
        with open(xmlpath, 'rb') as f:
            info = metadata(f.read(256 * 1024))
    except OSError:
        return None
    if not info or info['id'] not in TARGET_IDS:
        return None
    out = {'info': info, 'files': {}, 'scanned': 0, 'skipped': 0, 'source': 'installed'}
    done = 0
    scanned_bytes = 0
    for root, dirs, files in os.walk(path, followlinks=False):
        dirs[:] = sorted(d for d in dirs if d.lower() not in SKIP_DIRS and not os.path.islink(os.path.join(root, d)))
        for fname in sorted(files):
            relative = os.path.relpath(os.path.join(root, fname), path).replace('\\', '/')
            rel = clean_rel(relative)
            if rel is None or os.path.islink(os.path.join(root, fname)):
                continue
            done += 1
            if done > MAX_FILES:
                out['skipped'] += 1
                continue
            fp = os.path.join(root, fname)
            try:
                size = os.stat(fp).st_size
                if size > MAX_FILE_BYTES or scanned_bytes + size > MAX_TOTAL_SOURCE_BYTES:
                    out['skipped'] += 1
                    continue
                entry = {'size': size, 'sha256': sha_file(fp)}
                if rel.lower().endswith('.py') and size <= MAX_PY_PARSE:
                    with open(fp, 'rb') as f:
                        entry['functions'] = signatures(f.read())
                out['files'][rel] = entry
                out['scanned'] += 1
                scanned_bytes += size
            except (OSError, ValueError):
                out['skipped'] += 1
    return out


def inspect_cached_zip(path):
    try:
        with zipfile.ZipFile(path) as z:
            items = z.infolist()
            if len(items) > MAX_FILES * 4:
                return None
            candidates = [x for x in items if x.filename.lower().endswith('addon.xml') and x.file_size <= 256 * 1024]
            for item in candidates:
                prefix = item.filename[:-len('addon.xml')]
                try:
                    info = metadata(z.read(item))
                except (OSError, RuntimeError, zipfile.BadZipFile):
                    continue
                if not info or info['id'] not in TARGET_IDS:
                    continue
                result = {'info': info, 'files': {}, 'scanned': 0, 'skipped': 0, 'source': 'cached_previous_package'}
                scanned_bytes = 0
                for f in items:
                    if f.is_dir() or not f.filename.startswith(prefix):
                        continue
                    rel = clean_rel(f.filename[len(prefix):])
                    if rel is None:
                        continue
                    if (result['scanned'] >= MAX_FILES or f.file_size > MAX_FILE_BYTES or
                            scanned_bytes + f.file_size > MAX_TOTAL_SOURCE_BYTES):
                        result['skipped'] += 1
                        continue
                    try:
                        b = z.read(f)
                    except (OSError, RuntimeError, zipfile.BadZipFile):
                        result['skipped'] += 1
                        continue
                    entry = {'size': len(b), 'sha256': sha_bytes(b)}
                    if rel.lower().endswith('.py') and len(b) <= MAX_PY_PARSE:
                        entry['functions'] = signatures(b)
                    result['files'][rel] = entry
                    result['scanned'] += 1
                    scanned_bytes += len(b)
                result['archive_name'] = os.path.basename(path)
                return result
    except (OSError, RuntimeError, zipfile.BadZipFile, zipfile.LargeZipFile):
        return None
    return None


def numeric_version(version):
    """Strict numeric-only ordering; ambiguous vendor versions are not guessed."""
    match = re.fullmatch(r'[vV]?(\d+(?:\.\d+){0,5})', str(version).strip())
    if not match:
        return None
    numbers = tuple(int(n) for n in match.group(1).split('.'))
    return numbers + (0,) * (6 - len(numbers))


def verified_older(candidate, installed):
    left, right = numeric_version(candidate), numeric_version(installed)
    return left is not None and right is not None and left < right


def differences(old, now):
    a, b = old.get('files', {}), now.get('files', {})
    keys = sorted(set(a) | set(b))
    changes = []
    for rel in keys:
        va, vb = a.get(rel), b.get(rel)
        if va and vb and va['sha256'] == vb['sha256']:
            continue
        entry = {'file': rel, 'change': 'added' if va is None else 'removed' if vb is None else 'modified'}
        if va is not None and vb is not None and rel.endswith('.py'):
            fa, fb = set(va.get('functions', [])), set(vb.get('functions', []))
            entry['new_functions'] = sorted(fb - fa)[:40]
            entry['removed_functions'] = sorted(fa - fb)[:40]
        changes.append(entry)
    return {
        'older_version': old['info'].get('version', ''),
        'installed_version': now['info'].get('version', ''),
        'older_source': old.get('source', ''),
        'added_files': sum(c['change'] == 'added' for c in changes),
        'changed_files': sum(c['change'] == 'modified' for c in changes),
        'removed_files': sum(c['change'] == 'removed' for c in changes),
        'first_100_differences': changes[:100],
        'truncated_difference_list': len(changes) > 100,
    }


def collect(home, profile):
    addondir = os.path.join(home, 'addons')
    installed = {}
    # Inspect only target IDs; never read any user settings or add-on_data.
    for aid in TARGET_IDS:
        obj = inspect_directory(os.path.join(addondir, aid))
        if obj:
            installed[obj['info']['id']] = obj
    previous = None
    existing = sorted([x for x in os.listdir(profile) if x.startswith('snapshot-') and x.endswith('.json')]) if os.path.isdir(profile) else []
    if existing:
        try:
            with open(os.path.join(profile, existing[-1]), 'r', encoding='utf-8') as f:
                previous = json.load(f).get('installed', {})
        except (OSError, ValueError):
            pass
    cached = {}
    pkgdir = os.path.join(addondir, 'packages')
    if os.path.isdir(pkgdir):
        try:
            zips = sorted((os.path.join(pkgdir, f) for f in os.listdir(pkgdir) if f.lower().endswith('.zip')),
                          key=lambda x: os.path.getmtime(x), reverse=True)
        except OSError:
            zips = []
        candidates = [z for z in zips if os.path.basename(z).lower().startswith(tuple(x.lower() for x in TARGET_IDS))]
        count = {}
        for z in candidates[:80]:
            aid_hint = next((k for k in TARGET_IDS if os.path.basename(z).lower().startswith(k.lower() + '-')), None)
            if not aid_hint:
                continue
            if count.get(aid_hint, 0) >= MAX_ARCHIVES_PER_ID:
                continue
            count[aid_hint] = count.get(aid_hint, 0) + 1
            c = inspect_cached_zip(z)
            if not c:
                continue
            aid = c['info']['id']
            if aid not in installed or aid in cached:
                continue
            # Only an explicitly older numeric version is a verified prior package.
            # A newer cached ZIP or an ambiguous version is not an older baseline.
            if verified_older(c['info']['version'], installed[aid]['info']['version']):
                cached[aid] = c
    comparisons = {}
    for aid, obj in installed.items():
        if previous and aid in previous:
            # A previous on-device snapshot is direct historical evidence.
            comparisons[aid] = differences(previous[aid], obj)
        elif aid in cached:
            comparisons[aid] = differences(cached[aid], obj)
        else:
            comparisons[aid] = {'status': 'NO_OLDER_REFERENCE',
                                'note': 'No older cached package or prior scan; update cannot be established.'}
    return {
        'schema': 1,
        'timestamp_utc': utcstamp(),
        'scope': 'The Crew and WatchNixtoons2: installed files, versions, interfaces, cached versions only',
        'privacy': 'No credentials, settings values, raw provider URLs, media titles or search queries captured.',
        'installed': installed,
        'older_cached_reference': {k: v for k, v in cached.items()},
        'comparisons': comparisons,
        'warnings': [
            'A changed hash shows file differences, not necessarily their cause or a broken interface.',
            'Cached ZIP versions are treated as older only when strictly numeric version ordering proves it.',
            'Ambiguous version strings need a prior scan or independently verified package history.',
            'A missing older cached ZIP or previous scan prevents a historical update claim.',
            'This does not execute provider searches or diagnose live Infinity Search request-state errors.',
        ],
    }


def summary(report):
    lines = ['Infinity Provider Change Inspector', 'Read-only provider comparison', '']
    for aid in TARGET_IDS:
        item = report['installed'].get(aid)
        if not item:
            if aid in ('plugin.video.thecrew', 'plugin.video.watchnixtoons2', 'plugin.video.watchnixtoons2.kodi19'):
                lines.append('%s: Not found in this Kodi add-ons folder' % aid)
            continue
        cmp = report['comparisons'].get(aid, {})
        lines.append('%s  version %s' % (aid, item['info'].get('version', '?')))
        if 'older_version' in cmp:
            lines.append('  vs cached/prior %s: +%s / changed %s / -%s files' % (
                cmp['older_version'], cmp['added_files'], cmp['changed_files'], cmp['removed_files']))
        else:
            lines.append('  No verified older baseline available on device.')
    lines.extend(['', 'No existing add-on files or settings were modified.',
                  'Attach the exported ZIP to Codex for exact comparison.'])
    return '\n'.join(lines)


def main():
    import xbmc
    import xbmcgui
    import xbmcvfs

    translate = getattr(xbmcvfs, 'translatePath', None) or getattr(xbmc, 'translatePath')
    home = translate('special://home')
    profile = translate('special://profile/addon_data/script.infinity.provider.audit/')
    os.makedirs(profile, exist_ok=True)
    report = collect(home, profile)
    stamp = report['timestamp_utc']
    snapshot_file = os.path.join(profile, 'snapshot-%s.json' % stamp)
    export_file = os.path.join(profile, 'Infinity-Provider-Scan-%s.zip' % stamp)
    body = json.dumps(report, indent=2, sort_keys=True, ensure_ascii=False)
    with open(snapshot_file, 'w', encoding='utf-8') as f:
        f.write(body)
    with zipfile.ZipFile(export_file, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr('provider-snapshot.json', body)
        z.writestr('README.txt', summary(report) + '\n\nThis scan contains add-on source hashes and function names only.\n')
    dialog = xbmcgui.Dialog()
    dialog.textviewer('Infinity Provider Inspector', summary(report) + '\n\nSaved:\n' + export_file)
    if dialog.yesno('Infinity Provider Inspector', 'Export the report ZIP to another folder for sharing with Codex?'):
        try:
            folder = dialog.browse(0, 'Choose export folder', 'files', '', False, False, 'special://profile')
            folder = translate(folder) if folder and folder.startswith('special://') else folder
            if folder:
                target = os.path.join(folder, os.path.basename(export_file))
                if os.path.abspath(target) != os.path.abspath(export_file):
                    shutil.copyfile(export_file, target)
                dialog.ok('Infinity Provider Inspector', 'Report saved to:\n' + target)
        except Exception as exc:
            dialog.ok('Infinity Provider Inspector', 'Export failed: %s\nOriginal report remains in Kodi profile:\n%s' % (type(exc).__name__, export_file))


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        try:
            import xbmcgui
            xbmcgui.Dialog().ok('Infinity Provider Inspector', 'Scan could not finish (%s). No provider files were changed.' % type(error).__name__)
        except Exception:
            raise
