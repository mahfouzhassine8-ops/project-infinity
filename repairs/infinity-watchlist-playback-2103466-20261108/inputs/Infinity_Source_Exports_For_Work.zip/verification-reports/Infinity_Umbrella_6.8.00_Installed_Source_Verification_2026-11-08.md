# Infinity — Umbrella 6.8.00 installed source verification

**Status: PASS — both native movie and TV routes recognized in a read-only, source-only check.** Not an Android Search pass or installable fix.

## Verified uploaded evidence

- Export: `Infinity-Umbrella-Search-SourceOnly-6.8.00-20261108T071302Z.zip`
- Archive SHA-256: `20965283a7a10c1851bc924da95813f232d4d176c601b0607b0c9acd71e5c806`
- Installed add-on version: `plugin.video.umbrella` **6.8.00**, from actual `addon.xml` and collector receipt.
- ZIP structural integrity: PASS (6 unique safe members: 5 add-on code/manifest files plus exporter receipt, all receipt byte lengths and SHA-256 hashes matched).
- Export contains the requested source code only; no databases, user settings, account tokens, caches, saved data or logs were included.

## Exact approved compatibility check

The approved `native_search_compatibility.py` was obtained from the **actual installed Command Center export**. Its Git blob SHA-1, `73481c91020692581a84879299c1860c1a9796aa`, matches the approved source at commit `16af10e42265f9f5155efd54849b25871c50aa0f`. The installed Command Center's original `NAVIGATION-CONTRACTS.json` supplied the actual recognized Umbrella contract.

| Operation | Result | Original Umbrella route |
| --- | --- | --- |
| Movie Search | **PASS — recognized** | `action=movieSearchterm`, query key `name` |
| TV Search | **PASS — recognized** | `action=tvSearchterm`, query key `name` |

Source code was parsed as syntax trees; the provider's code was **not imported or executed**. For each route, the approved recognizer emitted SHA-256 pins of `umbrella.py`, `resources/lib/modules/router.py`, and its matching movie or TV menu Python source. Exact pins are included in the accompanying JSON report.

## Why the user's Infinity Search is still grayed out

The actual exported **Command Center 0.3.5.62** has the **original** `provider_inventory.py` SHA-256 `d9b51790c737f9cfa013806c6bf287ab37bd17cb798644ab0aaaf31ea37ae3e2` and original signed `INFINITY-MODULES.v1` SHA-256 `166c994d66503cfe3b3c70b7c4d4a10ce9778cea5e01a9838c9ce83a1a4b34bc` with **78** file records. The old inventory does **not import** `native_search_compatibility.recognize`, and the manifest does **not list** that added helper. Although the helper exists on disk, it is **not part of the authenticated active inventory path**.

This is a coherent explanation for both providers' unchanged gray state. The export cannot establish how that partial/inactive installation state arose or that an update will install successfully.

## Additional runtime consideration

The installed Umbrella `umbrella.py` includes a post-router check of `xbmc.getInfoLabel('Container.PluginName')`. This source-level detail could matter to Kodi invocations from another Search interface, but there is **no evidence yet that it causes a live failure**. It is not part of the approved recognition proof and should be considered only if actual routing later fails.

## Correct next engineering steps

1. Deliver these five actual Umbrella source/manifest files, plus the previously verified POV, Trakt, and CC62 exports to Work/Codex; compare **the real installed versions** rather than older provider fixture versions.
2. Produce **one complete original-key-authenticated CC62 correction** from the known good installed generation; include updated `provider_inventory.py`, approved `native_search_compatibility.py`, and newly regenerated **79-record** signed module manifest. Never replace files manually or downgrade CC62 to CC61.
3. Verify same-version install-over and recovery, then use the actual Fold to check whether both providers become selectable and searches/heading navigation work. This report does **not** verify playback or runtime search.
4. Preserve all other Command Center/Infinity/Cobra modules, original signing and recovery, stored data and unrelated add-ons. The native repeated-Search crash and Silent Mode Trakt corrections are **separate ongoing scopes**, not fixed by this source export.

**No changes were made to the phone or installed add-ons by this analysis.**
