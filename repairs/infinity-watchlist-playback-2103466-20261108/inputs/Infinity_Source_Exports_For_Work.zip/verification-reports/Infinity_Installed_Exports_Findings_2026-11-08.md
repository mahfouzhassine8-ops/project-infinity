# Infinity — Read-only review of three actual installed add-on exports

Date: November 8, 2026. Evidence: user-provided Kodi Health Center "Add-on files only" ZIPs. No device access, installation, modification, or private userdata inspection was performed.

## Input verification

| Export | Installed version | Archived source files | ZIP SHA-256 | Exporter receipt check |
| --- | --- | ---: | --- | --- |
| `script.infinity.commandcenter` | `0.3.5.62` | 65 | `983eb8db7961062fc542e660170aa74269762a428b1a0813fb68ac1936f0069d` | All 65 file hashes/sizes matched |
| `plugin.video.pov` | `6.11.02` | 210 | `a4e1196c6d13a9a90070c4261377f3e574b2aceba4f9df45d08adc95c5fd3cbd` | All 210 file hashes/sizes matched |
| `script.module.tmdbhelper.sync.trakt` | `1.2.8` | 145 | `de3c52d89c1f9ea8ae0fe20d63eb082948f8a9c962829ecbf916a95dc4d037ec` | All 145 file hashes/sizes matched |

All three KHC export receipts report `includes_saved_data=false`. They also report `globally_atomic=false`, so they should be treated as consistent per-file exports rather than a guaranteed atomic snapshot of every add-on at a single instant. All ZIP CRC integrity checks passed. There are no unlisted extra files beyond the KHC receipt.

## Command Center — direct reason the compatibility ZIP is inactive

- Installed Command Center declares `0.3.5.62` in `addon.xml`.
- Installed `INFINITY-MODULES.v1` SHA-256: `166c994d66503cfe3b3c70b7c4d4a10ce9778cea5e01a9838c9ce83a1a4b34bc`, the known original CC62 generation. It includes 78 source-file records and **does not list** `native_search_compatibility.py`.
- Installed `provider_inventory.py` SHA-256: `d9b51790c737f9cfa013806c6bf287ab37bd17cb798644ab0aaaf31ea37ae3e2`, the known original CC62 pre-fix file.
- Installed `native_search_compatibility.py` is **present**, and its Git blob SHA exactly matches the approved helper at commit `16af10e42265f9f5155efd54849b25871c50aa0f` (`73481c91020692581a84879299c1860c1a9796aa`). However, the old `provider_inventory.py` does not import it, no other Command Center Python source references it, and the signed module manifest does not contain it.
- This is evidence of an **incomplete/inactive compatibility update**, not evidence that the approved provider-recognition logic failed. The export alone cannot establish whether the helper was left by a rejected partial ZIP installation or another process.
- No downgrade, force overwrite, or manual file-copy repair is authorized. Need one complete original-key-authenticated CC62 generation with the approved updated inventory + helper + regenerated complete signed manifest, with installed-generation checks and recovery.

## POV — actual installed provider, approved recognition against actual source

- Installed `plugin.video.pov` is version `6.11.02` (not necessarily the same as the earlier CI fixture).
- The approved `native_search_compatibility.py` from the exported Command Center was independently run in a disposable, source-only AST check against the actual POV export and its own installed `NAVIGATION-CONTRACTS.json`; **both** operations were recognized: `('movie','search')` and `('tv','search')`.
- The static check used read-only ZIP member reads and did not import or execute POV provider modules, query external sources, modify settings, or perform actual Kodi navigation.
- Three distinct source files per route were source-pinned: `resources/lib/router.py`, `resources/lib/modules/entry.py`, and the relevant `resources/lib/menus/{movies,tvshows}.py`.
- This is strong evidence the approved compatibility correction should recognize *this installed POV version* once a complete compatible signed Command Center update is active. It does not establish live Android routing or playback.

## TMDbHelper Sync – Trakt — reference version verified by source identity

- Installed `script.module.tmdbhelper.sync.trakt` version `1.2.8`.
- Installed `resources/lib/tmdbhelper_sync_trakt/api/authenticator.py` SHA-256: `0f65df4f727927d34daa820a983b5dfb9838c1fbb1fe13d4deedf172ef5afcab`.
- Installed `resources/lib/tmdbhelper_sync_trakt/api/token.py` SHA-256: `08e98239ef6f3ed78e174c23503d0187f9ff73fd80295ace0017e683c86bd1e1`.
- **Both hashes match Codex's pinned original 1.2.8 preimages** from its Silent Mode correction at commit `514a82e513ed2ac00ba096d87011b3d3789cfb32`.
- The installed `notify_failure` still calls `Dialog().ok(...)` unconditionally, and the installed token handler does not forward the manual-login flag. Thus the Trakt Silent Mode correction has **not** been applied.
- The entire Trakt directory was not independently compared against the 146-file upstream source inventory. Version, manifest and the two specific patch preimages are verified; installation/recovery tests remain necessary.

## Missing item and next steps

The **Umbrella 6.8.00** export is not included; Health Center previously reported `Database has no readable SQLite header; raw fallback refused` during its export. Do not delete or alter any database, clear data, bypass validation, or assume the Umbrella code is damaged.

Provide these three actual add-on export ZIPs and this report to the existing Work/Codex release task. Work/Codex should reconcile the **incomplete CC62 signed generation**, use POV's confirmed native-route recognition, compare Umbrella actual code through a safe read-only source-only route, and incorporate the already scoped Trakt patch only after the remaining installed-source/release checks. The separate native Search GUI memory defect still requires independent ARM64/Android verification; the successful eight-search *test-only* correction is not a production fix. Cobra, playback, Watchlists, user data, and original signing/recovery remain protected.

References:
- Approved Umbrella/POV source: https://github.com/mahfouzhassine8-ops/project-infinity/commit/16af10e42265f9f5155efd54849b25871c50aa0f
- Trakt source candidate: https://github.com/mahfouzhassine8-ops/project-infinity/commit/514a82e513ed2ac00ba096d87011b3d3789cfb32
- Original 8-search controlled pass: https://github.com/mahfouzhassine8-ops/project-infinity/actions/runs/42443988873
