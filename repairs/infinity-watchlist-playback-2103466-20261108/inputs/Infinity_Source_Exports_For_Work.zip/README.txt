INFINITY / Fold installed-source evidence package (2026-11-08)

Includes four owner-supplied on-device exports and previously generated verification reports.
The Umbrella ZIP is a targeted source-only snapshot, not a full add-on export.
These files were provided in a separate ChatGPT conversation and were not automatically available to the ChatGPT Work workspace.
No patch or signed APK is included. Reverify origin, hashes, source preservation and signing gates before release.

